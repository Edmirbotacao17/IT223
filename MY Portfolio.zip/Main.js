const currentPage = window.location.pathname.split('/').pop();


const links = document.querySelectorAll('ul li a');
links.forEach(link => {
  const linkHref = link.getAttribute('href');
  if (linkHref === currentPage) {
    link.classList.add('active');
    link.querySelector('span').classList.add('active-indicator');
  }
});