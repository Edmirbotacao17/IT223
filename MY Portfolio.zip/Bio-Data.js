const link = document.createElement('a');
link.href = 'MY BIODATA.pdf';
link.download = 'MY BIODATA.pdf';
link.click();

window.open('MY BIODATA.pdf', '_blank');