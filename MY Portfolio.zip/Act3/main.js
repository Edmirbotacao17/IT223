const taskInput = document.getElementById('taskInput');
const addBtn = document.getElementById('addBtn');
const taskList = document.getElementById('taskList');

let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    addTask();
  }
});

function addTask() {
  const taskText = taskInput.value;
  if (taskText === '') {
    alert("Please enter a task!");
    return;
  }
  const li = document.createElement('li');
  li.innerHTML = `
    <span class="task-text">${taskText}</span>
    <button class="delete-btn">Delete</button>
  `;
  li.addEventListener('click', function(e) {
    if(e.target.tagName === 'BUTTON') return;
    li.classList.toggle('completed');
    updateTasks();
  });
  const deleteBtn = li.querySelector('.delete-btn');
  deleteBtn.addEventListener('click', function() {
    taskList.removeChild(li);
    updateTasks();
  });
  taskList.appendChild(li);
  tasks.push(taskText);
  localStorage.setItem('tasks', JSON.stringify(tasks));
  taskInput.value = '';
}

function updateTasks() {
  tasks = [];
  document.querySelectorAll('#taskList li span.task-text').forEach(span => {
    tasks.push(span.textContent);
  });
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Load tasks on init
tasks.forEach(task => {
  const li = document.createElement('li');
  li.innerHTML = `
    <span class="task-text">${task}</span>
    <button class="delete-btn">Delete</button>
  `;
  li.addEventListener('click', function(e) {
    if(e.target.tagName === 'BUTTON') return;
    li.classList.toggle('completed');
    updateTasks();
  });
  const deleteBtn = li.querySelector('.delete-btn');
  deleteBtn.addEventListener('click', function() {
    taskList.removeChild(li);
    updateTasks();
  });
  taskList.appendChild(li);
});